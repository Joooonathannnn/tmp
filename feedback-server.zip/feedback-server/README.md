# 负反馈看板 Tomcat 服务器版

该项目生成兼容 JDK 8和 Tomcat 9的 `feedback.war`。前端和后端位于同一 WAR中，所有内网用户读取服务器上的同一份 JSON数据。

## 功能

- 打开看板时自动读取服务器共享数据。
- 上传完整 JSON并整份替换当前数据。
- 新数据校验失败时保留当前数据。
- 替换前自动备份旧数据，最多保留20份。
- 提供健康检查接口。
- 第一版不做登录；任何可以访问页面的人都能上传数据。

## 构建要求

- JDK 8或更高版本。
- Maven 3.9.x。
- 构建产物以 Java 8为目标，可部署到 Tomcat 9.0.87。

在项目根目录执行：

```bash
mvn -f feedback-server/pom.xml clean package
```

成功后生成：

```text
feedback-server/target/feedback.war
```

如果使用公司 `build.yml`平台，把上面的 Maven命令配置为构建命令；JDK和 Maven镜像字段应使用公司模板规定的 `env`字段，不要自行猜测字段名。服务器只需要最终生成的 WAR，不需要安装 Maven。

## API

部署上下文为 `/feedback`：

```text
GET  /feedback/api/health
GET  /feedback/api/dataset
POST /feedback/api/dataset
```

POST请求体是 `application/json`，最大10 MB。每次上传整份替换，不做追加。

## 首次部署到EulerOS

### 1. 创建外置数据目录

服务器执行：

```bash
sudo mkdir -p /var/lib/feedback/backups
sudo chown -R tomcat:tomcat /var/lib/feedback
sudo chmod 750 /var/lib/feedback
sudo chmod 750 /var/lib/feedback/backups
```

### 2. 为Tomcat配置数据目录

执行：

```bash
sudo systemctl edit tomcat
```

写入：

```ini
[Service]
Environment="FEEDBACK_DATA_DIR=/var/lib/feedback"
```

保存后执行：

```bash
sudo systemctl daemon-reload
sudo systemctl restart tomcat
```

检查环境配置是否加载：

```bash
sudo systemctl show tomcat --property=Environment
```

### 3. 从构建电脑上传WAR

在构建电脑的 PowerShell中执行：

```powershell
scp "feedback-server\target\feedback.war" 用户名@服务器IP:/tmp/feedback.war
```

### 4. 替换当前静态目录

当前服务器已经存在 `/opt/tomcat/webapps/feedback`静态目录。先停止服务并把旧目录移出 `webapps`，不要直接删除：

```bash
sudo systemctl stop tomcat
sudo mkdir -p /opt/tomcat/deploy-backup
sudo mv /opt/tomcat/webapps/feedback /opt/tomcat/deploy-backup/feedback-static
```

如果目标备份目录已经存在，停止操作并先为它改一个新名称，避免覆盖旧备份。

复制 WAR并设置权限：

```bash
sudo cp /tmp/feedback.war /opt/tomcat/webapps/feedback.war
sudo chown tomcat:tomcat /opt/tomcat/webapps/feedback.war
sudo chmod 640 /opt/tomcat/webapps/feedback.war
sudo systemctl start tomcat
```

Tomcat会自动解压并发布 WAR。

## 部署验证

服务器内部执行：

```bash
curl -i http://127.0.0.1:8080/feedback/api/health
```

预期响应包含：

```json
{"status":"UP"}
```

尚未上传数据时：

```bash
curl -i http://127.0.0.1:8080/feedback/api/dataset
```

预期HTTP状态为404，响应包含：

```json
{"code":"NO_DATA","message":"尚未上传共享数据"}
```

浏览器访问：

```text
http://服务器IP:8080/feedback/
```

上传一份有效 JSON后，服务器应出现：

```text
/var/lib/feedback/current.json
```

第二次上传后检查备份：

```bash
ls -lh /var/lib/feedback/backups
```

## 日志与排错

```bash
sudo systemctl status tomcat
tail -n 100 /opt/tomcat/logs/catalina.out
```

如果出现“保存共享数据失败”，检查：

```bash
ls -ld /var/lib/feedback /var/lib/feedback/backups
sudo systemctl show tomcat --property=Environment
```

两个目录应归属 `tomcat:tomcat`，服务环境中应包含 `FEEDBACK_DATA_DIR=/var/lib/feedback`。

## 回滚到原静态页面

先停止Tomcat：

```bash
sudo systemctl stop tomcat
```

确认以下三个精确路径后，再移走服务器版：

```bash
sudo mv /opt/tomcat/webapps/feedback.war /opt/tomcat/deploy-backup/feedback-server.war
sudo mv /opt/tomcat/webapps/feedback /opt/tomcat/deploy-backup/feedback-server-expanded
sudo mv /opt/tomcat/deploy-backup/feedback-static /opt/tomcat/webapps/feedback
sudo systemctl start tomcat
```

回滚页面不会删除 `/var/lib/feedback`中的共享数据和备份。
