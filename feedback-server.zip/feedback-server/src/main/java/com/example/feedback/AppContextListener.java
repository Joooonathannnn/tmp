package com.example.feedback;

import com.fasterxml.jackson.databind.ObjectMapper;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Clock;
import java.util.logging.Logger;

public final class AppContextListener implements ServletContextListener {
    public static final String MAPPER_ATTRIBUTE = "feedback.objectMapper";
    public static final String VALIDATOR_ATTRIBUTE = "feedback.datasetValidator";
    public static final String STORE_ATTRIBUTE = "feedback.datasetStore";
    private static final Logger LOGGER = Logger.getLogger(AppContextListener.class.getName());

    @Override
    public void contextInitialized(ServletContextEvent event) {
        String configured = System.getenv("FEEDBACK_DATA_DIR");
        Path dataDir;
        if (configured == null || configured.trim().isEmpty()) {
            dataDir = Paths.get(System.getProperty("java.io.tmpdir"), "feedback-data");
            LOGGER.warning("FEEDBACK_DATA_DIR未配置，当前使用临时目录；生产环境必须显式配置外置数据目录");
        } else {
            dataDir = Paths.get(configured).toAbsolutePath().normalize();
        }

        ObjectMapper mapper = new ObjectMapper();
        DatasetValidator validator = new DatasetValidator();
        DatasetStore store = new DatasetStore(dataDir, mapper, Clock.systemDefaultZone());
        ServletContext context = event.getServletContext();
        context.setAttribute(MAPPER_ATTRIBUTE, mapper);
        context.setAttribute(VALIDATOR_ATTRIBUTE, validator);
        context.setAttribute(STORE_ATTRIBUTE, store);
    }
}
