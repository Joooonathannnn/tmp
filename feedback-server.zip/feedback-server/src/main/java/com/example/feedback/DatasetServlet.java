package com.example.feedback;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

import javax.servlet.ServletException;
import javax.servlet.ServletInputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.Optional;
import java.util.logging.Level;
import java.util.logging.Logger;

public final class DatasetServlet extends HttpServlet {
    static final long MAX_BODY_BYTES = 10L * 1024L * 1024L;
    private static final Logger LOGGER = Logger.getLogger(DatasetServlet.class.getName());

    private ObjectMapper mapper;
    private DatasetValidator validator;
    private DatasetStore store;

    public DatasetServlet() {
    }

    DatasetServlet(ObjectMapper mapper, DatasetValidator validator, DatasetStore store) {
        this.mapper = mapper;
        this.validator = validator;
        this.store = store;
    }

    @Override
    public void init() throws ServletException {
        if (mapper != null && validator != null && store != null) {
            return;
        }
        mapper = (ObjectMapper) getServletContext().getAttribute(AppContextListener.MAPPER_ATTRIBUTE);
        validator = (DatasetValidator) getServletContext().getAttribute(AppContextListener.VALIDATOR_ATTRIBUTE);
        store = (DatasetStore) getServletContext().getAttribute(AppContextListener.STORE_ATTRIBUTE);
        if (mapper == null || validator == null || store == null) {
            throw new ServletException("负反馈数据服务初始化失败");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        try {
            Optional<JsonNode> current = store.read();
            if (!current.isPresent()) {
                JsonResponses.error(mapper, response, HttpServletResponse.SC_NOT_FOUND,
                    "NO_DATA", "尚未上传共享数据");
                return;
            }
            JsonResponses.write(mapper, response, HttpServletResponse.SC_OK, current.get());
        } catch (IOException error) {
            LOGGER.log(Level.SEVERE, "读取共享数据失败", error);
            JsonResponses.error(mapper, response, HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
                "READ_FAILED", "读取共享数据失败");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        if (request.getContentLengthLong() > MAX_BODY_BYTES) {
            JsonResponses.error(mapper, response, HttpServletResponse.SC_REQUEST_ENTITY_TOO_LARGE,
                "PAYLOAD_TOO_LARGE", "上传文件不能超过10 MB");
            return;
        }
        String contentType = request.getContentType();
        if (contentType == null || !contentType.toLowerCase(Locale.ROOT).startsWith("application/json")) {
            JsonResponses.error(mapper, response, HttpServletResponse.SC_UNSUPPORTED_MEDIA_TYPE,
                "JSON_REQUIRED", "请上传JSON格式数据");
            return;
        }

        try {
            byte[] body = readLimitedBody(request.getInputStream());
            JsonNode parsed = mapper.readTree(new String(body, StandardCharsets.UTF_8));
            validator.validate(parsed);
            JsonNode stored = store.replace((ObjectNode) parsed);

            ObjectNode result = mapper.createObjectNode();
            result.put("success", true);
            result.put("recordCount", stored.path("records").size());
            result.put("generatedAt", stored.path("generatedAt").asText());
            JsonResponses.write(mapper, response, HttpServletResponse.SC_OK, result);
        } catch (PayloadTooLargeException error) {
            JsonResponses.error(mapper, response, HttpServletResponse.SC_REQUEST_ENTITY_TOO_LARGE,
                "PAYLOAD_TOO_LARGE", "上传文件不能超过10 MB");
        } catch (DatasetValidationException error) {
            JsonResponses.error(mapper, response, HttpServletResponse.SC_BAD_REQUEST,
                "VALIDATION_FAILED", error.getMessage());
        } catch (JsonProcessingException error) {
            JsonResponses.error(mapper, response, HttpServletResponse.SC_BAD_REQUEST,
                "INVALID_JSON", "JSON语法错误");
        } catch (IOException error) {
            LOGGER.log(Level.SEVERE, "保存共享数据失败", error);
            JsonResponses.error(mapper, response, HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
                "SAVE_FAILED", "保存共享数据失败");
        }
    }

    private byte[] readLimitedBody(ServletInputStream input) throws IOException, PayloadTooLargeException {
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        byte[] buffer = new byte[8192];
        long total = 0;
        int count;
        while ((count = input.read(buffer)) != -1) {
            total += count;
            if (total > MAX_BODY_BYTES) {
                throw new PayloadTooLargeException();
            }
            output.write(buffer, 0, count);
        }
        return output.toByteArray();
    }

    private static final class PayloadTooLargeException extends Exception {
        private static final long serialVersionUID = 1L;
    }
}
