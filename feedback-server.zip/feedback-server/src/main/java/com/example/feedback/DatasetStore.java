package com.example.feedback;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.time.Clock;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;

public final class DatasetStore {
    private static final int MAX_BACKUPS = 20;
    private static final DateTimeFormatter BACKUP_TIME = DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss-SSS");

    private final Path dataDir;
    private final Path currentFile;
    private final Path backupDir;
    private final ObjectMapper mapper;
    private final Clock clock;

    public DatasetStore(Path dataDir, ObjectMapper mapper, Clock clock) {
        this.dataDir = dataDir;
        this.currentFile = dataDir.resolve("current.json");
        this.backupDir = dataDir.resolve("backups");
        this.mapper = mapper;
        this.clock = clock;
    }

    public synchronized Optional<JsonNode> read() throws IOException {
        if (!Files.exists(currentFile)) {
            return Optional.empty();
        }
        return Optional.of(mapper.readTree(currentFile.toFile()));
    }

    public synchronized JsonNode replace(ObjectNode dataset) throws IOException {
        Files.createDirectories(dataDir);
        Files.createDirectories(backupDir);

        ObjectNode normalized = dataset.deepCopy();
        normalized.put("generatedAt", OffsetDateTime.now(clock).format(DateTimeFormatter.ISO_OFFSET_DATE_TIME));

        Path temporary = Files.createTempFile(dataDir, "current-", ".tmp");
        try {
            writeAndSync(temporary, normalized);
            if (Files.exists(currentFile)) {
                Path backup = nextBackupPath();
                Files.copy(currentFile, backup, StandardCopyOption.COPY_ATTRIBUTES);
                pruneBackups();
            }
            moveIntoPlace(temporary);
        } finally {
            Files.deleteIfExists(temporary);
        }
        return normalized;
    }

    private void writeAndSync(Path target, JsonNode dataset) throws IOException {
        byte[] serialized = mapper.writerWithDefaultPrettyPrinter().writeValueAsBytes(dataset);
        FileOutputStream stream = new FileOutputStream(target.toFile());
        try {
            stream.write(serialized);
            stream.flush();
            stream.getFD().sync();
        } finally {
            stream.close();
        }
    }

    private String backupTimestamp() {
        return BACKUP_TIME.format(OffsetDateTime.now(clock).withOffsetSameInstant(ZoneOffset.UTC));
    }

    private Path nextBackupPath() {
        String prefix = "dataset-" + backupTimestamp();
        int suffix = 0;
        Path candidate = backupDir.resolve(prefix + String.format("-%04d.json", suffix));
        while (Files.exists(candidate)) {
            suffix++;
            candidate = backupDir.resolve(prefix + String.format("-%04d.json", suffix));
        }
        return candidate;
    }

    private void moveIntoPlace(Path temporary) throws IOException {
        try {
            Files.move(temporary, currentFile, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
        } catch (AtomicMoveNotSupportedException error) {
            Files.move(temporary, currentFile, StandardCopyOption.REPLACE_EXISTING);
        }
    }

    private void pruneBackups() throws IOException {
        List<Path> backups = new ArrayList<Path>();
        DirectoryStream<Path> stream = Files.newDirectoryStream(backupDir, "dataset-*.json");
        try {
            for (Path path : stream) {
                backups.add(path);
            }
        } finally {
            stream.close();
        }
        Collections.sort(backups, new Comparator<Path>() {
            @Override
            public int compare(Path left, Path right) {
                return right.getFileName().toString().compareTo(left.getFileName().toString());
            }
        });
        for (int index = MAX_BACKUPS; index < backups.size(); index++) {
            Files.deleteIfExists(backups.get(index));
        }
    }
}
