package com.example.feedback;

public final class DatasetValidationException extends RuntimeException {
    public DatasetValidationException(String message) {
        super(message);
    }
}
