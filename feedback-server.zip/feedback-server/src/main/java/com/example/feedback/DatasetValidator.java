package com.example.feedback;

import com.fasterxml.jackson.databind.JsonNode;

import java.time.OffsetDateTime;
import java.time.format.DateTimeParseException;
import java.util.HashSet;
import java.util.Set;

public final class DatasetValidator {
    private static final String[] REQUIRED_TEXT_FIELDS = {
        "id", "timestamp", "feedbackSummary", "feedbackContent",
        "rootCauseCategory", "rootCauseAnalysis", "improvementSuggestion"
    };

    public void validate(JsonNode dataset) {
        if (dataset == null || !dataset.isObject() || !dataset.path("records").isArray()) {
            throw new DatasetValidationException("数据顶层必须包含 records 数组");
        }

        Set<String> ids = new HashSet<String>();
        int index = 0;
        for (JsonNode record : dataset.path("records")) {
            index++;
            validateRecord(record, index, ids);
        }
    }

    private void validateRecord(JsonNode record, int index, Set<String> ids) {
        String label = "第 " + index + " 条";
        if (record == null || !record.isObject()) {
            throw new DatasetValidationException(label + "轨迹格式无效");
        }

        for (String field : REQUIRED_TEXT_FIELDS) {
            JsonNode value = record.get(field);
            if (value == null || !value.isTextual() || value.asText().trim().isEmpty()) {
                throw new DatasetValidationException(label + "缺少字段 " + field);
            }
        }

        String id = record.path("id").asText();
        if (!ids.add(id)) {
            throw new DatasetValidationException("轨迹ID重复：" + id);
        }

        try {
            OffsetDateTime.parse(record.path("timestamp").asText());
        } catch (DateTimeParseException error) {
            throw new DatasetValidationException(label + "的时间格式无效");
        }

        JsonNode project = record.get("project");
        if (project == null || !project.isObject()) {
            throw new DatasetValidationException(label + "必须且只能关联一个项目对象");
        }
        requireProjectText(project, "id", label);
        requireProjectText(project, "name", label);

        JsonNode mapping = project.get("dataMapping");
        if (mapping == null || !mapping.isObject()) {
            throw new DatasetValidationException(label + "的项目数据映射必须为对象");
        }
    }

    private void requireProjectText(JsonNode project, String field, String label) {
        JsonNode value = project.get(field);
        if (value == null || !value.isTextual() || value.asText().trim().isEmpty()) {
            throw new DatasetValidationException(label + "的项目缺少 " + field);
        }
    }
}
