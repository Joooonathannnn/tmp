package com.example.feedback;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public final class HealthServlet extends HttpServlet {
    private ObjectMapper mapper;

    @Override
    public void init() throws ServletException {
        mapper = (ObjectMapper) getServletContext().getAttribute(AppContextListener.MAPPER_ATTRIBUTE);
        if (mapper == null) {
            throw new ServletException("健康检查初始化失败");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        ObjectNode payload = mapper.createObjectNode();
        payload.put("status", "UP");
        JsonResponses.write(mapper, response, HttpServletResponse.SC_OK, payload);
    }
}
