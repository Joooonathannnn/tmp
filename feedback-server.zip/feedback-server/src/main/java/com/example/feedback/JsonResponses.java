package com.example.feedback;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public final class JsonResponses {
    private JsonResponses() {
    }

    public static void write(ObjectMapper mapper, HttpServletResponse response, int status, JsonNode payload)
            throws IOException {
        response.setStatus(status);
        response.setCharacterEncoding("UTF-8");
        response.setContentType("application/json");
        mapper.writeValue(response.getOutputStream(), payload);
    }

    public static void error(ObjectMapper mapper, HttpServletResponse response, int status, String code, String message)
            throws IOException {
        ObjectNode payload = mapper.createObjectNode();
        payload.put("code", code);
        payload.put("message", message);
        write(mapper, response, status, payload);
    }
}
