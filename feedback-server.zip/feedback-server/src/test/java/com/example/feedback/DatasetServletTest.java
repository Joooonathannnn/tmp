package com.example.feedback;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;

import javax.servlet.ReadListener;
import javax.servlet.ServletInputStream;
import javax.servlet.ServletOutputStream;
import javax.servlet.WriteListener;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.time.Clock;
import java.time.Instant;
import java.time.ZoneOffset;
import java.util.concurrent.atomic.AtomicInteger;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class DatasetServletTest {
    @Rule
    public TemporaryFolder folder = new TemporaryFolder();

    private ObjectMapper mapper;
    private DatasetStore store;
    private DatasetServlet servlet;

    @Before
    public void setUp() {
        mapper = new ObjectMapper();
        store = new DatasetStore(
            folder.getRoot().toPath(),
            mapper,
            Clock.fixed(Instant.parse("2026-08-25T02:30:00Z"), ZoneOffset.UTC)
        );
        servlet = new DatasetServlet(mapper, new DatasetValidator(), store);
    }

    @Test
    public void getReturnsNoDataBeforeFirstUpload() throws Exception {
        ResponseCapture response = new ResponseCapture();
        servlet.doGet(mock(HttpServletRequest.class), response.response);

        assertEquals(404, response.status.get());
        assertEquals("NO_DATA", mapper.readTree(response.body()).path("code").asText());
    }

    @Test
    public void postPersistsDatasetAndGetReturnsIt() throws Exception {
        ResponseCapture postResponse = new ResponseCapture();
        servlet.doPost(jsonRequest(validJson("first")), postResponse.response);

        assertEquals(200, postResponse.status.get());
        assertEquals(1, mapper.readTree(postResponse.body()).path("recordCount").asInt());

        ResponseCapture getResponse = new ResponseCapture();
        servlet.doGet(mock(HttpServletRequest.class), getResponse.response);
        JsonNode dataset = mapper.readTree(getResponse.body());
        assertEquals(200, getResponse.status.get());
        assertEquals("first", dataset.path("datasetName").asText());
        assertEquals("2026-08-25T02:30:00Z", dataset.path("generatedAt").asText());
    }

    @Test
    public void invalidUploadDoesNotReplaceCurrentDataset() throws Exception {
        servlet.doPost(jsonRequest(validJson("current")), new ResponseCapture().response);

        ResponseCapture invalidResponse = new ResponseCapture();
        servlet.doPost(jsonRequest("{\"records\":[{}]}"), invalidResponse.response);

        assertEquals(400, invalidResponse.status.get());
        assertTrue(mapper.readTree(invalidResponse.body()).path("message").asText().contains("缺少字段"));
        assertEquals("current", store.read().get().path("datasetName").asText());
    }

    @Test
    public void rejectsDeclaredBodyLargerThanTenMegabytes() throws Exception {
        HttpServletRequest request = mock(HttpServletRequest.class);
        when(request.getContentLengthLong()).thenReturn(DatasetServlet.MAX_BODY_BYTES + 1);
        ResponseCapture response = new ResponseCapture();

        servlet.doPost(request, response.response);

        assertEquals(413, response.status.get());
        assertEquals("PAYLOAD_TOO_LARGE", mapper.readTree(response.body()).path("code").asText());
    }

    private HttpServletRequest jsonRequest(String json) throws Exception {
        byte[] bytes = json.getBytes(StandardCharsets.UTF_8);
        HttpServletRequest request = mock(HttpServletRequest.class);
        when(request.getContentLengthLong()).thenReturn((long) bytes.length);
        when(request.getContentType()).thenReturn("application/json; charset=UTF-8");
        when(request.getInputStream()).thenReturn(new ByteArrayServletInputStream(bytes));
        return request;
    }

    private String validJson(String name) {
        return "{"
            + "\"datasetName\":\"" + name + "\","
            + "\"records\":[{"
            + "\"id\":\"T-1\","
            + "\"timestamp\":\"2026-08-25T10:00:00+08:00\","
            + "\"feedbackSummary\":\"摘要\","
            + "\"feedbackContent\":\"内容\","
            + "\"rootCauseCategory\":\"数据加载\","
            + "\"rootCauseAnalysis\":\"接口超时\","
            + "\"improvementSuggestion\":\"增加缓存\","
            + "\"project\":{\"id\":\"P-1\",\"name\":\"经营看板\",\"dataMapping\":{}}"
            + "}]}";
    }

    private static final class ByteArrayServletInputStream extends ServletInputStream {
        private final ByteArrayInputStream delegate;

        private ByteArrayServletInputStream(byte[] bytes) {
            delegate = new ByteArrayInputStream(bytes);
        }

        @Override
        public int read() {
            return delegate.read();
        }

        @Override
        public int read(byte[] buffer, int offset, int length) {
            return delegate.read(buffer, offset, length);
        }

        @Override
        public boolean isFinished() {
            return delegate.available() == 0;
        }

        @Override
        public boolean isReady() {
            return true;
        }

        @Override
        public void setReadListener(ReadListener listener) {
        }
    }

    private static final class ResponseCapture {
        private final HttpServletResponse response = mock(HttpServletResponse.class);
        private final AtomicInteger status = new AtomicInteger();
        private final ByteArrayOutputStream body = new ByteArrayOutputStream();

        private ResponseCapture() throws Exception {
            doAnswer(invocation -> {
                status.set(invocation.getArgument(0));
                return null;
            }).when(response).setStatus(anyInt());
            when(response.getOutputStream()).thenReturn(new ServletOutputStream() {
                @Override
                public void write(int value) {
                    body.write(value);
                }

                @Override
                public boolean isReady() {
                    return true;
                }

                @Override
                public void setWriteListener(WriteListener listener) {
                }
            });
        }

        private String body() {
            return new String(body.toByteArray(), StandardCharsets.UTF_8);
        }
    }
}
