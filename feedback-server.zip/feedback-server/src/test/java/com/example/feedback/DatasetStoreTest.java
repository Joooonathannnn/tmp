package com.example.feedback;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;

import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Clock;
import java.time.Instant;
import java.time.ZoneOffset;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class DatasetStoreTest {
    @Rule
    public TemporaryFolder folder = new TemporaryFolder();

    private final ObjectMapper mapper = new ObjectMapper();
    private final Clock clock = Clock.fixed(Instant.parse("2026-08-25T02:30:00Z"), ZoneOffset.UTC);

    @Test
    public void firstReadHasNoDataset() throws Exception {
        DatasetStore store = new DatasetStore(folder.getRoot().toPath(), mapper, clock);
        assertFalse(store.read().isPresent());
    }

    @Test
    public void replacementPersistsDatasetAndUsesServerTime() throws Exception {
        DatasetStore store = new DatasetStore(folder.getRoot().toPath(), mapper, clock);
        JsonNode stored = store.replace(dataset("first"));

        assertEquals("first", store.read().get().path("datasetName").asText());
        assertEquals("2026-08-25T02:30:00Z", stored.path("generatedAt").asText());
        assertTrue(Files.exists(folder.getRoot().toPath().resolve("current.json")));
    }

    @Test
    public void replacementBacksUpPreviousDataset() throws Exception {
        DatasetStore store = new DatasetStore(folder.getRoot().toPath(), mapper, clock);
        store.replace(dataset("first"));
        store.replace(dataset("second"));

        assertEquals("second", store.read().get().path("datasetName").asText());
        assertEquals(1, countBackups(folder.getRoot().toPath().resolve("backups")));
    }

    @Test
    public void retainsOnlyTwentyNewestBackups() throws Exception {
        DatasetStore store = new DatasetStore(folder.getRoot().toPath(), mapper, clock);
        for (int index = 0; index < 26; index++) {
            store.replace(dataset("dataset-" + index));
        }

        assertEquals("dataset-25", store.read().get().path("datasetName").asText());
        assertEquals(20, countBackups(folder.getRoot().toPath().resolve("backups")));
    }

    private int countBackups(Path directory) throws Exception {
        int count = 0;
        DirectoryStream<Path> stream = Files.newDirectoryStream(directory, "dataset-*.json");
        try {
            for (Path ignored : stream) {
                count++;
            }
        } finally {
            stream.close();
        }
        return count;
    }

    private ObjectNode dataset(String name) {
        ObjectNode dataset = mapper.createObjectNode();
        dataset.put("datasetName", name);
        dataset.putArray("records");
        return dataset;
    }
}
