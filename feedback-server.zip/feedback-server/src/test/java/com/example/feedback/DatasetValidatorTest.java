package com.example.feedback;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Test;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

public class DatasetValidatorTest {
    private final ObjectMapper mapper = new ObjectMapper();
    private final DatasetValidator validator = new DatasetValidator();

    @Test
    public void acceptsValidDataset() throws Exception {
        validator.validate(mapper.readTree(validJson("T-1")));
    }

    @Test
    public void rejectsMissingRecords() throws Exception {
        assertInvalid("{}", "records 数组");
    }

    @Test
    public void rejectsEmptyRequiredText() throws Exception {
        assertInvalid(validJson("T-1").replace("\"摘要\"", "\"\""), "feedbackSummary");
    }

    @Test
    public void rejectsInvalidTimestamp() throws Exception {
        assertInvalid(validJson("T-1").replace("2026-08-25T10:00:00+08:00", "昨天"), "时间格式无效");
    }

    @Test
    public void rejectsDuplicateIds() throws Exception {
        String first = validRecord("T-1");
        assertInvalid("{\"records\":[" + first + "," + first + "]}", "轨迹ID重复");
    }

    @Test
    public void rejectsProjectArray() throws Exception {
        assertInvalid(validJson("T-1").replace(projectJson(), "[]"), "一个项目对象");
    }

    @Test
    public void rejectsMappingString() throws Exception {
        assertInvalid(validJson("T-1").replace("\"dataMapping\":{}", "\"dataMapping\":\"x\""), "映射必须为对象");
    }

    private void assertInvalid(String json, String expectedMessage) throws Exception {
        JsonNode dataset = mapper.readTree(json);
        try {
            validator.validate(dataset);
            fail("expected DatasetValidationException");
        } catch (DatasetValidationException error) {
            assertTrue(error.getMessage(), error.getMessage().contains(expectedMessage));
        }
    }

    private String validJson(String id) {
        return "{\"datasetName\":\"测试\",\"records\":[" + validRecord(id) + "]}";
    }

    private String validRecord(String id) {
        return "{"
            + "\"id\":\"" + id + "\","
            + "\"timestamp\":\"2026-08-25T10:00:00+08:00\","
            + "\"source\":\"Android\","
            + "\"feedbackSummary\":\"摘要\","
            + "\"feedbackContent\":\"完整内容\","
            + "\"rootCauseCategory\":\"数据加载\","
            + "\"rootCauseAnalysis\":\"接口超时\","
            + "\"improvementSuggestion\":\"增加缓存\","
            + "\"project\":" + projectJson()
            + "}";
    }

    private String projectJson() {
        return "{\"id\":\"P-1\",\"name\":\"经营看板\",\"dataMapping\":{}}";
    }
}
