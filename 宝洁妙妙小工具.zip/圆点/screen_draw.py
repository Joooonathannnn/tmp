# -*- coding: utf-8 -*-
"""屏幕画笔：按住 Shift 在屏幕上绘制图案，连按两次 Ctrl 清屏。"""
import ctypes
import ctypes.wintypes as wt
import queue
import threading
import time
import tkinter as tk
from tkinter import ttk

try:
    ctypes.windll.shcore.SetProcessDpiAwareness(2)
except Exception:
    try:
        ctypes.windll.user32.SetProcessDPIAware()
    except Exception:
        pass

user32 = ctypes.windll.user32

VK_LSHIFT = 0xA0
VK_RSHIFT = 0xA1
VK_LCONTROL = 0xA2
VK_RCONTROL = 0xA3

GWL_EXSTYLE = -20
WS_EX_LAYERED = 0x00080000
WS_EX_TRANSPARENT = 0x00000020
SWP_NOSIZE = 0x0001
SWP_NOMOVE = 0x0002
SWP_NOZORDER = 0x0004
SWP_FRAMECHANGED = 0x0020

WH_MOUSE_LL = 14
HC_ACTION = 0
WM_LBUTTONDOWN = 0x0201
WM_LBUTTONUP = 0x0202
WM_LBUTTONDBLCLK = 0x0203
WM_RBUTTONDOWN = 0x0204
WM_RBUTTONUP = 0x0205
WM_MBUTTONDOWN = 0x0207
WM_MBUTTONUP = 0x0208
WM_MOUSEWHEEL = 0x020A
WM_XBUTTONDOWN = 0x020B
WM_XBUTTONUP = 0x020C
WM_QUIT = 0x0012

TRANSPARENT_COLOR = "#010203"
POLL_MS = 8
CTRL_DOUBLE_MS = 500

BLOCKED_MESSAGES = {
    WM_LBUTTONDOWN, WM_LBUTTONUP, WM_LBUTTONDBLCLK, WM_RBUTTONDOWN, WM_RBUTTONUP,
    WM_MBUTTONDOWN, WM_MBUTTONUP, WM_MOUSEWHEEL, WM_XBUTTONDOWN, WM_XBUTTONUP,
}

HOOKPROC = ctypes.WINFUNCTYPE(ctypes.c_ssize_t, ctypes.c_int, wt.WPARAM, wt.LPARAM)

user32.SetWindowsHookExW.restype = ctypes.c_void_p
user32.SetWindowsHookExW.argtypes = [ctypes.c_int, HOOKPROC, ctypes.c_void_p, ctypes.c_ulong]
user32.CallNextHookEx.restype = ctypes.c_ssize_t
user32.CallNextHookEx.argtypes = [ctypes.c_void_p, ctypes.c_int, wt.WPARAM, wt.LPARAM]
user32.UnhookWindowsHookEx.restype = ctypes.c_int


class MSLLHOOKSTRUCT(ctypes.Structure):
    _fields_ = [
        ("pt", wt.POINT),
        ("mouseData", ctypes.c_ulong),
        ("flags", ctypes.c_ulong),
        ("time", ctypes.c_ulong),
        ("dwExtraInfo", ctypes.POINTER(ctypes.c_ulong)),
    ]


SIZES = {
    "small": {"name": "小", "radius": 25, "width": 6},
    "medium": {"name": "中", "radius": 50, "width": 12},
    "large": {"name": "大", "radius": 90, "width": 20},
}
COLORS = [
    ("红", "#FF3B30"),
    ("黄", "#FFCC00"),
    ("绿", "#34C759"),
    ("蓝", "#007AFF"),
    ("白", "#FFFFFF"),
    ("黑", "#000000"),
]


def key_down(vk):
    return bool(user32.GetAsyncKeyState(vk) & 0x8000)


class ScreenDrawApp:
    def __init__(self, root):
        self.root = root
        root.title("屏幕画笔 配置")
        root.resizable(False, False)

        self.enabled_var = tk.BooleanVar(value=True)
        self.mode_var = tk.StringVar(value="circle")
        self.size_var = tk.StringVar(value="medium")
        self.color_var = tk.StringVar(value=COLORS[0][1])

        self.overlay = None
        self.canvas = None
        self.overlay_hwnd = 0
        self.config_hwnd = 0

        self._cfg = {
            "enabled": True,
            "mode": "circle",
            "color": COLORS[0][1],
            "radius": SIZES["medium"]["radius"],
            "width": SIZES["medium"]["width"],
        }
        self.draw_queue = queue.Queue()

        self.hook_thread = None
        self._hook_tid = 0
        self._hook_handle = 0
        self._hook_proc_ref = None
        self.ring_count = 0

        self.prev_ctrl = False
        self.last_ctrl_press = 0.0

        self._build_config_window()
        self._build_overlay()
        self.config_hwnd = self._top_hwnd(self.root)
        self._start_hook()

        root.protocol("WM_DELETE_WINDOW", self.root.withdraw)
        root.after(POLL_MS, self.tick)

    def _build_config_window(self):
        main = ttk.Frame(self.root, padding=12)
        main.pack(fill="both", expand=True)

        ttk.Label(main, text="屏幕画笔", font=("Microsoft YaHei UI", 13, "bold")).pack(anchor="w")
        ttk.Label(
            main,
            text="按住 Shift + 左键 绘制　连按两次 Ctrl 清屏",
            foreground="#666666",
        ).pack(anchor="w", pady=(2, 8))

        self.enable_check = ttk.Checkbutton(
            main, text="启用绘制指令识别", variable=self.enabled_var,
            command=self.on_enable_toggle,
        )
        self.enable_check.pack(anchor="w")

        mode_frame = ttk.LabelFrame(main, text="图案类型", padding=8)
        mode_frame.pack(fill="x", pady=(8, 0))
        for text, value in (("固定圆（实心）", "circle"), ("圆环（空心）", "ring"), ("圆环+数字", "num_ring")):
            ttk.Radiobutton(mode_frame, text=text, value=value, variable=self.mode_var).pack(anchor="w")

        size_frame = ttk.LabelFrame(main, text="大小预设", padding=8)
        size_frame.pack(fill="x", pady=(8, 0))
        for key, info in SIZES.items():
            ttk.Radiobutton(size_frame, text=info["name"], value=key, variable=self.size_var).pack(
                side="left", padx=(0, 16)
            )

        color_frame = ttk.LabelFrame(main, text="颜色", padding=8)
        color_frame.pack(fill="x", pady=(8, 0))
        color_row = ttk.Frame(color_frame)
        color_row.pack(anchor="w")
        for name, value in COLORS:
            tk.Button(
                color_row, text=name, bg=value, width=4, relief="ridge",
                command=lambda v=value: self.color_var.set(v),
            ).pack(side="left", padx=(0, 6), pady=2)

        btn_row = ttk.Frame(main)
        btn_row.pack(fill="x", pady=(12, 0))
        ttk.Button(btn_row, text="清空绘制", command=self.clear_canvas).pack(side="left")
        ttk.Button(btn_row, text="退出程序", command=self.quit).pack(side="right")

        ttk.Label(
            main,
            text="提示：绘制期间（按住 Shift）会拦截鼠标点击，不误触下层应用",
            foreground="#999999",
        ).pack(anchor="w", pady=(10, 0))

    def _build_overlay(self):
        sm_x = user32.GetSystemMetrics(76)
        sm_y = user32.GetSystemMetrics(77)
        sm_cx = user32.GetSystemMetrics(78)
        sm_cy = user32.GetSystemMetrics(79)

        self.overlay = tk.Toplevel(self.root)
        self.overlay.overrideredirect(True)
        self.overlay.geometry("%dx%d+%d+%d" % (sm_cx, sm_cy, sm_x, sm_y))
        self.overlay.configure(bg=TRANSPARENT_COLOR)
        self.overlay.attributes("-topmost", True)
        self.overlay.attributes("-transparentcolor", TRANSPARENT_COLOR)

        self.canvas = tk.Canvas(
            self.overlay, bg=TRANSPARENT_COLOR, highlightthickness=0, bd=0
        )
        self.canvas.pack(fill="both", expand=True)
        self.overlay.update_idletasks()
        self.overlay_hwnd = self._top_hwnd(self.overlay)
        self.set_click_through(True)

    def _top_hwnd(self, widget):
        hwnd = widget.winfo_id()
        while True:
            parent = user32.GetParent(hwnd)
            if not parent:
                return hwnd
            hwnd = parent

    def set_click_through(self, enabled=True):
        if not self.overlay_hwnd:
            return
        try:
            style = user32.GetWindowLongW(self.overlay_hwnd, GWL_EXSTYLE)
            style |= WS_EX_LAYERED
            if enabled:
                style |= WS_EX_TRANSPARENT
            else:
                style &= ~WS_EX_TRANSPARENT
            user32.SetWindowLongW(self.overlay_hwnd, GWL_EXSTYLE, style)
            user32.SetWindowPos(
                self.overlay_hwnd, 0, 0, 0, 0, 0,
                SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER | SWP_FRAMECHANGED,
            )
        except Exception:
            pass

    def on_enable_toggle(self):
        self._cfg["enabled"] = bool(self.enabled_var.get())

    def clear_canvas(self):
        if self.canvas:
            self.canvas.delete("all")
        self.ring_count = 0

    def quit(self):
        self.root.destroy()

    def _start_hook(self):
        def run():
            self._hook_tid = threading.get_ident()
            self._hook_handle = user32.SetWindowsHookExW(WH_MOUSE_LL, self._hook_proc_ref, 0, 0)
            if not self._hook_handle:
                return
            msg = wt.MSG()
            while user32.GetMessageW(ctypes.byref(msg), 0, 0, 0) != 0:
                user32.TranslateMessage(ctypes.byref(msg))
                user32.DispatchMessageW(ctypes.byref(msg))
            user32.UnhookWindowsHookEx(self._hook_handle)

        self._hook_proc_ref = HOOKPROC(self._hook_proc)
        self.hook_thread = threading.Thread(target=run, daemon=True)
        self.hook_thread.start()

    def _hook_proc(self, n_code, w_param, l_param):
        if n_code == HC_ACTION:
            msg = int(w_param)
            if msg in BLOCKED_MESSAGES:
                info = ctypes.cast(l_param, ctypes.POINTER(MSLLHOOKSTRUCT)).contents
                if self._should_swallow(msg, info.pt):
                    self._handle_draw_input(msg, info.pt)
                    return 1
        return user32.CallNextHookEx(0, n_code, w_param, l_param)

    def _should_swallow(self, msg, pt):
        cfg = self._cfg
        if not cfg["enabled"]:
            return False
        if not (key_down(VK_LSHIFT) or key_down(VK_RSHIFT)):
            return False
        if self.config_hwnd and user32.IsWindowVisible(self.config_hwnd):
            rect = wt.RECT()
            user32.GetWindowRect(self.config_hwnd, ctypes.byref(rect))
            if rect.left <= pt.x <= rect.right and rect.top <= pt.y <= rect.bottom:
                return False
        return True

    def _handle_draw_input(self, msg, pt):
        cfg = self._cfg
        if msg in (WM_LBUTTONDOWN, WM_LBUTTONDBLCLK):
            self.draw_queue.put(
                ("shape", pt.x, pt.y, cfg["mode"], cfg["color"],
                 cfg["radius"], cfg["width"])
            )

    def tick(self):
        try:
            self._cfg = {
                "enabled": bool(self.enabled_var.get()),
                "mode": self.mode_var.get(),
                "color": self.color_var.get(),
                "radius": SIZES[self.size_var.get()]["radius"],
                "width": SIZES[self.size_var.get()]["width"],
            }
            self._drain()
            self._poll_keys()
        except Exception:
            pass
        finally:
            try:
                self.root.after(POLL_MS, self.tick)
            except Exception:
                pass

    def _drain(self):
        while True:
            try:
                item = self.draw_queue.get_nowait()
            except queue.Empty:
                break
            kind = item[0]
            if kind == "shape":
                _, x, y, mode, color, r, w = item
                if mode == "circle":
                    self.canvas.create_oval(
                        x - r, y - r, x + r, y + r,
                        fill=color, outline="",
                    )
                elif mode == "ring":
                    self.canvas.create_oval(
                        x - r, y - r, x + r, y + r,
                        outline=color, width=w,
                    )
                else:
                    self.ring_count += 1
                    self.canvas.create_oval(
                        x - r, y - r, x + r, y + r,
                        outline=color, width=w,
                    )
                    self.canvas.create_text(
                        x, y, text=str(self.ring_count),
                        fill=color, font=("Arial", max(10, int(r * 0.75)), "bold"),
                    )

    def _poll_keys(self):
        ctrl = key_down(VK_LCONTROL) or key_down(VK_RCONTROL)
        if ctrl and not self.prev_ctrl:
            now = time.monotonic()
            if self._cfg["enabled"] and now - self.last_ctrl_press <= CTRL_DOUBLE_MS / 1000.0:
                self.clear_canvas()
            self.last_ctrl_press = now
        self.prev_ctrl = ctrl


def main():
    root = tk.Tk()
    ScreenDrawApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()