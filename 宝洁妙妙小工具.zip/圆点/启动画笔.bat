@echo off
start "" "D:\miniconda\pythonw.exe" "%~dp0screen_draw.py"